setwd("C:\\Users\\USER\\OneDrive\\Desktop\\IT24102497")
getwd()

#1)
#i. Binomial distribution
#ii.
1-pbinom(46,50,0.85,lower.tail=TRUE)

#2)
#i. Number of calls per hour
#ii. Possion distribution.
#iii. 
dpois(15,12)
