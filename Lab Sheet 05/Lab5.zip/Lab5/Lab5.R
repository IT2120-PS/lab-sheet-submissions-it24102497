setwd("C:\\Users\\it24102497\\Desktop\\IT24102497")
Delivery.Times <- read.table("Exercise - Lab 05.txt", header=FALSE)
View(Delivery.Times)
names(Delivery.Times) <- "Time"
attach(Delivery.Times)
hist(Time, main="Histogram for Delivery Times", breaks=seq(20, 70, length=10), right=FALSE)
breaks <- seq(20, 70, length=10)
freq <- hist(Time, breaks=breaks, right=FALSE, plot=FALSE)$counts
classes <- c()
for(i in 1:(length(breaks)-1)){
  classes[i] <- paste0("[", breaks[i], ", ", breaks[i+1], ")")
}
cbind(Classes = classes, Frequency = freq)
cumfreq <- cumsum(freq)
upper <- breaks[2:length(breaks)]
plot(upper, cumfreq, type="o", main="Cumulative Frequency Polygon (Ogive) for Delivery Times", xlab="Delivery Time", ylab="Cumulative Frequency")